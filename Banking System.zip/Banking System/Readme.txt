its a cpp project 
which i did in my University puspose is Lab Project 
it is basically a banking system and when you run it console is asking for a password and pthe password is "csi218" and by entering the password you can see all the available menus 
and apart form this i built an interesting thing, it shows the amount in written form 
suppose you have "1050" taka in your balance it shows you "one thousand fifty taka"